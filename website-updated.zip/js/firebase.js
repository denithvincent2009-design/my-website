// ============================================================
// NEXORA INNOVATORS — Firebase initialization
// Uses Firebase v10 modular SDK loaded straight from the CDN,
// so this project needs NO build step / npm install to run.
// ============================================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-app.js";
import {
  initializeFirestore, persistentLocalCache, persistentSingleTabManager,
  connectFirestoreEmulator
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";
import {
  getAuth, connectAuthEmulator, signInAnonymously
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js";
import {
  getStorage, connectStorageEmulator
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-storage.js";

// -----------------------------------------------------------
// Your web app's Firebase configuration.
// This config is safe to expose publicly — Firebase client
// config is not a secret. Real access control happens in
// firestore.rules / storage.rules and Firebase Authentication.
// -----------------------------------------------------------
const firebaseConfig = {
  apiKey: "AIzaSyAEosVxuZCqbJW6fomSHN9ufjyTM8ZKrOw",
  authDomain: "nexora-web-284c4.firebaseapp.com",
  projectId: "nexora-web-284c4",
  storageBucket: "nexora-web-284c4.firebasestorage.app",
  messagingSenderId: "1015027407981",
  appId: "1:1015027407981:web:0ec1017c0b1fe351c07364",
  measurementId: "G-F724P2NZ89"
};

export const app = initializeApp(firebaseConfig);

// Local (IndexedDB) cache turned on: after the first visit, Firestore
// reads are served instantly from the browser cache while Firebase
// quietly syncs fresh data in the background — this is what makes
// repeat page loads and page-to-page navigation feel instant.
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({ tabManager: persistentSingleTabManager() })
});
export const auth = getAuth(app);
export const storage = getStorage(app);

// Set window.USE_EMULATORS = true in the browser console before
// load if you want to develop against local Firebase emulators.
if (window.USE_EMULATORS) {
  connectFirestoreEmulator(db, "localhost", 8080);
  connectAuthEmulator(auth, "http://localhost:9099");
  connectStorageEmulator(storage, "localhost", 9199);
}

// Visitor contact chat uses Firebase Anonymous Authentication so visitors do not need an account.
export async function ensureVisitorAuth() {
  if (auth.currentUser) return auth.currentUser;
  const cred = await signInAnonymously(auth);
  return cred.user;
}
