// ============================================================
// Data access layer
// TEAM is code-managed with local profile images.
// PROJECTS use a large local reference library plus Firebase
// for admin-created / uploaded projects and images.
// ============================================================
import { db, storage, auth, ensureVisitorAuth } from "./firebase.js";
import {
  collection, doc, getDocs, getDoc, addDoc, updateDoc, deleteDoc,
  query, orderBy, where, serverTimestamp, onSnapshot, limit
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";
import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-storage.js";
import { signInWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js";
import { TEAM_SEED, PROJECTS_SEED } from "./seed-data.js";

const _cache = {};
function cacheGet(key) { return _cache[key]; }
function cacheSet(key, value) { _cache[key] = value; return value; }
function cacheClear(key) { delete _cache[key]; }

const col = (name) => collection(db, name);

function localProjects() {
  return PROJECTS_SEED.map((p, i) => ({
    id: `local-${i + 1}`,
    ...p,
    _local: true,
    createdAt: p.createdAt || 0
  }));
}

// ---------- TEAM: LOCAL CODE ONLY ----------
export async function fetchTeam() {
  return cacheSet("team", TEAM_SEED.map((m, i) => ({ id: `team-${i + 1}`, ...m, _local: true })));
}

// ---------- PROJECTS: LOCAL LIBRARY + FIREBASE ----------
export async function fetchProjects({ onlyPublished = true } = {}) {
  const cacheKey = onlyPublished ? "projects-pub" : "projects-all";
  const cached = cacheGet(cacheKey);
  if (cached) return cached;

  let remote = [];
  try {
    const q = onlyPublished
      ? query(col("projects"), where("published", "==", true))
      : query(col("projects"), orderBy("createdAt", "desc"));
    const snap = await getDocs(q);
    remote = snap.docs.map(d => ({ id: d.id, ...d.data(), _local: false }));
  } catch (e) {
    console.warn("[data] Firebase projects unavailable; using local project library.", e);
  }

  // Firebase projects override a local project with the same slug/title.
  const remoteKeys = new Set(remote.map(p => p.slug || String(p.title || "").toLowerCase().trim()));
  const local = localProjects().filter(p => {
    if (onlyPublished && p.published === false) return false;
    const key = p.slug || String(p.title || "").toLowerCase().trim();
    return !remoteKeys.has(key);
  });

  const list = [...remote, ...local];
  if (onlyPublished) list.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
  return cacheSet(cacheKey, list);
}

export async function fetchProjectById(id) {
  if (String(id).startsWith("local-")) {
    const idx = Number(String(id).split("-")[1]) - 1;
    return PROJECTS_SEED[idx] ? { id, ...PROJECTS_SEED[idx], _local: true, createdAt: 0 } : null;
  }
  const snap = await getDoc(doc(db, "projects", id));
  return snap.exists() ? { id: snap.id, ...snap.data(), _local: false } : null;
}

export async function saveProject(id, data) {
  cacheClear("projects-pub"); cacheClear("projects-all");
  if (id && !String(id).startsWith("local-")) {
    await updateDoc(doc(db, "projects", id), { ...data, updatedAt: serverTimestamp() });
    return id;
  }
  // Local reference projects are never mutated in the code library.
  // Saving from Admin creates a Firebase project copy, allowing image uploads.
  const ref2 = await addDoc(col("projects"), { ...data, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
  return ref2.id;
}

export async function deleteProject(id) {
  if (String(id).startsWith("local-")) throw new Error("Reference library projects are built into the website and cannot be deleted.");
  cacheClear("projects-pub"); cacheClear("projects-all");
  await deleteDoc(doc(db, "projects", id));
}

// ---------- STORAGE: project images ----------
export function uploadImage(file, folder, onProgress) {
  return new Promise((resolve, reject) => {
    const safeName = file.name.replace(/[^a-z0-9.]/gi, "_");
    const path = `${folder}/${Date.now()}_${safeName}`;
    const storageRef = ref(storage, path);
    const task = uploadBytesResumable(storageRef, file);
    task.on("state_changed",
      snap => onProgress && onProgress(Math.round((snap.bytesTransferred / snap.totalBytes) * 100)),
      reject,
      async () => resolve(await getDownloadURL(task.snapshot.ref))
    );
  });
}

export function deleteImageByUrl(url) {
  return deleteObject(ref(storage, url)).catch(() => {});
}

// ---------- AUTH ----------
export function loginAdmin(email, password) {
  return signInWithEmailAndPassword(auth, email, password);
}
export function logoutAdmin() {
  return signOut(auth);
}
export function watchAuth(cb) {
  return onAuthStateChanged(auth, cb);
}

// ---------- SEEDING: PROJECTS ONLY ----------
export async function seedDatabase() {
  const projSnap = await getDocs(col("projects"));
  if (projSnap.empty) {
    // Smart Flow is the only project pushed automatically.
    const smart = PROJECTS_SEED[0];
    await addDoc(col("projects"), { ...smart, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
  }
  cacheClear("projects-pub"); cacheClear("projects-all");
}


// ---------- CONTACT COMMUNICATION SYSTEM ----------
// Visitor -> Contact System -> Firestore -> NEXORA Admin Inbox
export async function createContactConversation({ name, email, subject = "General enquiry" }) {
  const user = await ensureVisitorAuth();
  const conversation = await addDoc(col("contactConversations"), {
    ownerUid: user.uid,
    name: String(name || "").trim(),
    email: String(email || "").trim(),
    subject: String(subject || "General enquiry").trim(),
    status: "open",
    lastMessage: "",
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
  return conversation.id;
}

export async function sendContactMessage(conversationId, text) {
  const user = await ensureVisitorAuth();
  const clean = String(text || "").trim();
  if (!clean) throw new Error("Message is empty.");
  await addDoc(collection(db, "contactConversations", conversationId, "messages"), {
    senderUid: user.uid,
    senderType: "visitor",
    text: clean,
    createdAt: serverTimestamp()
  });
  await updateDoc(doc(db, "contactConversations", conversationId), {
    lastMessage: clean.slice(0, 180),
    updatedAt: serverTimestamp(),
    status: "open"
  });
}

export function watchContactMessages(conversationId, callback) {
  const q = query(
    collection(db, "contactConversations", conversationId, "messages"),
    orderBy("createdAt", "asc")
  );
  return onSnapshot(q, snap => callback(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
}

export async function getAdminContactConversations() {
  const q = query(col("contactConversations"), orderBy("updatedAt", "desc"), limit(100));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export function watchAdminContactConversations(callback) {
  const q = query(col("contactConversations"), orderBy("updatedAt", "desc"), limit(100));
  return onSnapshot(q, snap => callback(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
}

export async function sendAdminContactMessage(conversationId, text) {
  const clean = String(text || "").trim();
  if (!clean || !auth.currentUser) throw new Error("Message is empty or admin is not signed in.");
  await addDoc(collection(db, "contactConversations", conversationId, "messages"), {
    senderUid: auth.currentUser.uid,
    senderType: "admin",
    text: clean,
    createdAt: serverTimestamp()
  });
  await updateDoc(doc(db, "contactConversations", conversationId), {
    lastMessage: clean.slice(0, 180),
    updatedAt: serverTimestamp(),
    status: "open"
  });
}
