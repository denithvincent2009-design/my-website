import {
  fetchProjects, fetchProjectById, saveProject, deleteProject,
  uploadImage, logoutAdmin,
  getAdminContactConversations, watchAdminContactConversations, watchContactMessages, sendAdminContactMessage
} from "./data.js";
import { PROJECT_CATEGORIES, PROJECT_STATUSES } from "./seed-data.js";
import { $, $$, escapeHtml, fmtDate, toast, confirmDialog } from "./app.js";

let view = "overview";
let editingId = null;

const NAV_ITEMS = [
  { key: "overview", label: "Dashboard", icon: "📊" },
  { key: "projects", label: "Projects", icon: "🛠" },
  { key: "inbox", label: "Contact Inbox", icon: "💬" },
];

export async function renderAdminDashboard(appEl, user, onLoggedOut) {
  if (!user) {
    appEl.innerHTML = `<div class="page nx-section container" style="max-width:460px;text-align:center;"><div class="glass" style="padding:30px;">Checking session…</div></div>`;
    const { watchAuth } = await import("./data.js");
    let settled = false;
    watchAuth((u) => {
      if (settled) return; settled = true;
      if (u) renderAdminDashboard(appEl, u, onLoggedOut);
      else { toast("Please log in to access the admin dashboard.", "error"); onLoggedOut(); }
    });
    return;
  }
  view = "overview"; editingId = null;
  appEl.innerHTML = shell(user);
  wireShell(appEl, onLoggedOut);
  await renderView(appEl.querySelector("#admin-main"));
}

function shell(user) {
  return `<div class="page admin-shell">
    <button class="btn btn-ghost btn-sm admin-mobile-burger" id="admin-burger" style="position:fixed;top:76px;left:14px;z-index:150;">☰ Menu</button>
    <aside class="admin-sidebar glass" id="admin-sidebar">
      <div style="padding:0 8px 18px;font-family:Orbitron;font-size:13px;opacity:.6;">NEXORA<br><b style="color:var(--white);">ADMIN PANEL</b></div>
      ${NAV_ITEMS.map(n => `<a href="javascript:void(0)" data-view="${n.key}" class="${view === n.key ? "active" : ""}">${n.icon} ${n.label}</a>`).join("")}
      <a href="javascript:void(0)" id="admin-logout" style="margin-top:20px;color:#ff9aa8;">🚪 Logout</a>
    </aside>
    <div class="admin-main" id="admin-main"></div>
  </div>`;
}

function wireShell(appEl, onLoggedOut) {
  $$("#admin-sidebar a[data-view]", appEl).forEach(a => a.addEventListener("click", async () => {
    view = a.dataset.view; editingId = null;
    $$("#admin-sidebar a[data-view]", appEl).forEach(x => x.classList.remove("active"));
    a.classList.add("active");
    $("#admin-sidebar", appEl).classList.remove("open");
    await renderView(appEl.querySelector("#admin-main"));
  }));
  $("#admin-logout", appEl).addEventListener("click", async () => {
    if (!(await confirmDialog("You'll be signed out of the admin panel.", { title: "Log out?", danger: false }))) return;
    await logoutAdmin(); toast("Logged out.", "success"); onLoggedOut();
  });
  $("#admin-burger", appEl)?.addEventListener("click", () => $("#admin-sidebar", appEl).classList.toggle("open"));
}

async function renderView(main) {
  main.innerHTML = `<div class="state-box"><div class="spinner"></div>Loading…</div>`;
  try {
    if (view === "overview") { main.innerHTML = await viewOverview(); return wireOverviewExtras(main); }
    if (view === "projects") { main.innerHTML = await viewProjectsList(); return wireProjectsList(main); }
    if (view === "projects-edit") { main.innerHTML = await viewProjectForm(editingId); return wireProjectForm(main); }
    if (view === "inbox") { main.innerHTML = await viewInbox(); return wireInbox(main); }
  } catch (e) {
    console.error(e); main.innerHTML = `<div class="state-box glass">⚠ Failed to load. ${escapeHtml(e.message || "")}</div>`;
  }
}
function goto(main, v, id = null) { view = v; editingId = id; renderView(main); }


let inboxConversationId = null;
let inboxMessagesUnsub = null;
let inboxListUnsub = null;

async function viewInbox() {
  const conversations = await getAdminContactConversations();
  return `<div class="admin-toolbar"><h2 style="margin:0;">Contact Inbox</h2><span style="opacity:.6;font-size:13px;">Real-time visitor conversations</span></div>
    <div class="contact-inbox-grid">
      <div class="glass inbox-list" id="inbox-list">
        ${conversations.length ? conversations.map(c => `<button class="inbox-item ${inboxConversationId === c.id ? "active" : ""}" data-conversation="${escapeHtml(c.id)}">
          <b>${escapeHtml(c.name || "Visitor")}</b><span>${escapeHtml(c.email || "")}</span><small>${escapeHtml(c.lastMessage || "New conversation")}</small>
        </button>`).join("") : `<div style="padding:28px;opacity:.6;">No visitor messages yet.</div>`}
      </div>
      <div class="glass inbox-chat" id="inbox-chat">
        <div style="padding:28px;opacity:.55;text-align:center;">Select a conversation to reply.</div>
      </div>
    </div>`;
}
function wireInbox(main) {
  const list = $("#inbox-list", main);
  $$("[data-conversation]", main).forEach(b => b.addEventListener("click", () => openInboxConversation(main, b.dataset.conversation)));
  inboxListUnsub?.();
  inboxListUnsub = watchAdminContactConversations(conversations => {
    if (!list) return;
    list.innerHTML = conversations.length ? conversations.map(c => `<button class="inbox-item ${inboxConversationId === c.id ? "active" : ""}" data-conversation="${escapeHtml(c.id)}">
      <b>${escapeHtml(c.name || "Visitor")}</b><span>${escapeHtml(c.email || "")}</span><small>${escapeHtml(c.lastMessage || "New conversation")}</small>
    </button>`).join("") : `<div style="padding:28px;opacity:.6;">No visitor messages yet.</div>`;
    $$("[data-conversation]", list).forEach(b => b.addEventListener("click", () => openInboxConversation(main, b.dataset.conversation)));
  });
}
async function openInboxConversation(main, id) {
  inboxConversationId = id;
  inboxMessagesUnsub?.();
  const chat = $("#inbox-chat", main);
  chat.innerHTML = `<div class="state-box"><div class="spinner"></div>Opening conversation…</div>`;
  const conversations = await getAdminContactConversations();
  const c = conversations.find(x => x.id === id);
  if (!c) return;
  chat.innerHTML = `<div class="inbox-chat-head"><b>${escapeHtml(c.name || "Visitor")}</b><span>${escapeHtml(c.email || "")}</span><small>${escapeHtml(c.subject || "General enquiry")}</small></div>
    <div class="inbox-messages" id="inbox-messages"></div>
    <form class="inbox-composer" id="inbox-composer"><textarea id="inbox-input" required maxlength="2000" placeholder="Reply to visitor…"></textarea><button class="btn btn-solid">Reply</button></form>`;
  const msgs = $("#inbox-messages", chat);
  inboxMessagesUnsub = watchContactMessages(id, arr => {
    msgs.innerHTML = arr.map(m => `<div class="inbox-msg ${m.senderType === "admin" ? "admin" : "visitor"}"><div>${escapeHtml(m.text || "")}</div></div>`).join("");
    msgs.scrollTop = msgs.scrollHeight;
  });
  $("#inbox-composer", chat).addEventListener("submit", async e => {
    e.preventDefault();
    const input = $("#inbox-input", chat), btn = e.currentTarget.querySelector("button");
    if (!input.value.trim()) return;
    btn.disabled = true;
    try { await sendAdminContactMessage(id, input.value); input.value = ""; }
    catch { toast("Reply failed.", "error"); }
    finally { btn.disabled = false; input.focus(); }
  });
}

async function viewOverview() {
  const projects = await fetchProjects({ onlyPublished: false });
  return `<h2>Dashboard</h2>
    <div class="grid-3" style="margin-top:20px;">
      <div class="glass stat-card"><div class="num">${projects.length}</div><div class="label">Total Projects</div></div>
      <div class="glass stat-card"><div class="num">${projects.filter(p => p.published !== false).length}</div><div class="label">Published Projects</div></div>
      <div class="glass stat-card"><div class="num">6</div><div class="label">Team Members (Code)</div></div>
    </div>
    <div class="admin-toolbar" style="margin-top:30px;"><h3 style="margin:0;">Cloud-managed content</h3><div class="flex-c gap-2"><button class="btn btn-solid btn-sm" id="quick-add-project">+ New Project</button></div></div>
    <p style="opacity:.65;line-height:1.7;max-width:720px;">Only <b>Projects + Project Images</b> use Firebase. Team members and all other NEXORA website content remain inside the project code.</p>`;
}
function wireOverviewExtras(main) { $("#quick-add-project", main)?.addEventListener("click", () => goto(main, "projects-edit", null)); }

async function viewProjectsList() {
  const projects = await fetchProjects({ onlyPublished: false });
  return `<div class="admin-toolbar"><h2 style="margin:0;">Projects</h2><button class="btn btn-solid btn-sm" id="add-project">+ Add Project</button></div>
    <table class="admin-table glass" style="padding:10px;"><thead><tr><th></th><th>Title</th><th>Category</th><th>Status</th><th>Published</th><th>Date</th><th>Actions</th></tr></thead><tbody>
    ${projects.map(p => `<tr><td>${p.coverImageUrl ? `<img class="table-thumb" src="${escapeHtml(p.coverImageUrl)}">` : `<div class="table-thumb"></div>`}</td><td>${escapeHtml(p.title)}</td><td>${escapeHtml(p.category || "")}</td><td>${escapeHtml(p.status || "")}</td><td>${p.published !== false ? "✅" : "—"}</td><td>${fmtDate(p.createdAt)}</td><td class="flex-c gap-2"><button class="btn btn-ghost btn-sm" data-edit="${p.id}">Edit</button>${String(p.id).startsWith("seed-") ? "" : `<button class="btn btn-danger btn-sm" data-del="${p.id}">Delete</button>`}</td></tr>`).join("") || `<tr><td colspan="7" style="text-align:center;opacity:.6;padding:26px;">No projects yet.</td></tr>`}
    </tbody></table>`;
}
function wireProjectsList(main) {
  $("#add-project", main)?.addEventListener("click", () => goto(main, "projects-edit", null));
  $$('[data-edit]', main).forEach(b => b.addEventListener("click", () => goto(main, "projects-edit", b.dataset.edit)));
  $$('[data-del]', main).forEach(b => b.addEventListener("click", async () => {
    if (!(await confirmDialog("This project will be permanently deleted.", { title: "Delete project?" }))) return;
    await deleteProject(b.dataset.del); toast("Project deleted.", "success"); goto(main, "projects");
  }));
}

async function viewProjectForm(id) {
  const p = id ? await fetchProjectById(id) : {};
  const f = v => escapeHtml(v ?? "");
  return `<div class="admin-toolbar"><h2 style="margin:0;">${id ? "Edit" : "Add"} Project</h2><button class="btn btn-ghost btn-sm" id="back-list">&larr; Back to list</button></div>
  <form id="project-form" class="glass" style="padding:26px;max-width:760px;">
    <div class="field"><label>Title *</label><input name="title" required value="${f(p.title)}" /></div>
    <div class="field"><label>Short Description</label><textarea name="shortDescription">${f(p.shortDescription)}</textarea></div>
    <div class="field"><label>Description</label><textarea name="description" style="min-height:140px;">${f(p.description)}</textarea></div>
    <div class="grid-2"><div class="field"><label>Category</label><select name="category" required>${PROJECT_CATEGORIES.map(c => `<option ${p.category === c ? "selected" : ""}>${c}</option>`).join("")}</select></div>
    <div class="field"><label>Status</label><select name="status">${PROJECT_STATUSES.map(s => `<option ${p.status === s ? "selected" : ""}>${s}</option>`).join("")}</select></div></div>
    <div class="field"><label>Technologies (comma separated)</label><input name="technologies" value="${f((p.technologies || []).join(", "))}" /></div>
    <div class="field"><label>Team Members (comma separated)</label><input name="teamMemberNames" value="${f((p.teamMemberNames || []).join(", "))}" /></div>
    <div class="field"><label>Cover Image</label><input type="file" name="coverFile" accept="image/*" />${p.coverImageUrl ? `<img src="${f(p.coverImageUrl)}" style="width:160px;border-radius:10px;margin-top:8px;">` : ""}<div id="cover-progress" style="font-size:12px;opacity:.6;margin-top:4px;"></div></div>
    <div class="field"><label>Gallery Images</label><input type="file" name="galleryFiles" accept="image/*" multiple /><div id="gallery-progress" style="font-size:12px;opacity:.6;margin-top:4px;"></div></div>
    <div class="field"><label>Video URL</label><input name="videoUrl" value="${f(p.videoUrl)}" /></div>
    <label class="flex-c gap-2"><input type="checkbox" name="featured" style="width:auto;" ${p.featured ? "checked" : ""}/> Featured</label>
    <label class="flex-c gap-2"><input type="checkbox" name="published" style="width:auto;" ${p.published !== false ? "checked" : ""}/> Published</label>
    <button type="submit" class="btn btn-solid mt-2" id="project-save-btn">Save Project</button>
  </form>`;
}
function wireProjectForm(main) {
  $("#back-list", main).addEventListener("click", () => goto(main, "projects"));
  $("#project-form", main).addEventListener("submit", async e => {
    e.preventDefault(); const btn = $("#project-save-btn", main); btn.disabled = true; btn.textContent = "Saving…";
    try {
      const fd = new FormData(e.currentTarget);
      let coverImageUrl = e.currentTarget.querySelector("img")?.src || "";
      const cover = fd.get("coverFile");
      if (cover?.size) coverImageUrl = await uploadImage(cover, "projects/covers", pct => $("#cover-progress", main).textContent = `Uploading… ${pct}%`);
      const galleryFiles = [...(fd.getAll("galleryFiles") || [])].filter(x => x?.size);
      const galleryUrls = [];
      for (const gf of galleryFiles) galleryUrls.push(await uploadImage(gf, "projects/gallery", pct => $("#gallery-progress", main).textContent = `Uploading ${gf.name}… ${pct}%`));
      const existingGallery = Array.isArray((await fetchProjectById(editingId || ""))?.galleryUrls) ? (await fetchProjectById(editingId || ""))?.galleryUrls : [];
      const data = { title: fd.get("title").trim(), shortDescription: fd.get("shortDescription").trim(), description: fd.get("description").trim(), category: fd.get("category"), status: fd.get("status"), technologies: fd.get("technologies").split(",").map(x=>x.trim()).filter(Boolean), teamMemberNames: fd.get("teamMemberNames").split(",").map(x=>x.trim()).filter(Boolean), coverImageUrl, galleryUrls: galleryUrls.length ? [...existingGallery, ...galleryUrls] : existingGallery, videoUrl: fd.get("videoUrl").trim(), featured: fd.get("featured") === "on", published: fd.get("published") === "on" };
      await saveProject(editingId, data); toast("Project saved to Firebase.", "success"); goto(main, "projects");
    } catch (err) { toast("Save failed: " + err.message, "error"); btn.disabled = false; btn.textContent = "Save Project"; }
  });
}
