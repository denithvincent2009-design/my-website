export const ELECTRONICS = [
  {
    "id": 1,
    "name": "Arduino Uno R3",
    "category": "Microcontrollers",
    "slug": "arduino-uno-r3",
    "image": "assets/electronics/photos/Ardino Uno R3.jpeg",
    "description": "Arduino Uno R3 is an educational electronics component used in microcontrollers projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "microcontrollers",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 2,
    "name": "NodeMCU ESP8266",
    "category": "Microcontrollers",
    "slug": "nodemcu-esp8266",
    "image": "assets/electronics/photos/NODEMCU ESP8266.jpeg",
    "description": "NodeMCU ESP8266 is an educational electronics component used in microcontrollers projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "microcontrollers",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 3,
    "name": "ESP32",
    "category": "Microcontrollers",
    "slug": "esp32",
    "image": "assets/electronics/photos/ESP32.jpeg",
    "description": "ESP32 is an educational electronics component used in microcontrollers projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "microcontrollers",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 4,
    "name": "Arduino Nano",
    "category": "Microcontrollers",
    "slug": "arduino-nano",
    "image": "assets/electronics/photos/Ardino nano.jpeg",
    "description": "Arduino Nano is an educational electronics component used in microcontrollers projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "microcontrollers",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 5,
    "name": "Arduino Mega 2560",
    "category": "Microcontrollers",
    "slug": "arduino-mega-2560",
    "image": "assets/electronics/photos/Ardino Mega 2560.jpeg",
    "description": "Arduino Mega 2560 is an educational electronics component used in microcontrollers projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "microcontrollers",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 6,
    "name": "HC-SR04 Ultrasonic Sensor",
    "category": "Sensors",
    "slug": "hc-sr04-ultrasonic-sensor",
    "image": "assets/electronics/photos/HC-SR04 Uitrasonic sensor.jpeg",
    "description": "HC-SR04 Ultrasonic Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 7,
    "name": "DHT11 Temperature & Humidity Sensor",
    "category": "Sensors",
    "slug": "dht11-temperature-humidity-sensor",
    "image": "assets/electronics/photos/DHT11 Temperature and humidity sensor.jpeg",
    "description": "DHT11 Temperature & Humidity Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 8,
    "name": "DHT22 Precision Temperature Sensor",
    "category": "Sensors",
    "slug": "dht22-precision-temperature-sensor",
    "image": "assets/electronics/photos/DHT22 PRECISION TEMPERATURE SENSOR.jpeg",
    "description": "DHT22 Precision Temperature Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 9,
    "name": "LDR (Light Dependent Resistor)",
    "category": "Sensors",
    "slug": "ldr-light-dependent-resistor",
    "image": "assets/electronics/photos/LDR.jpeg",
    "description": "LDR (Light Dependent Resistor) is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 10,
    "name": "PIR Motion Sensor (HC-SR501)",
    "category": "Sensors",
    "slug": "pir-motion-sensor-hc-sr501",
    "image": "assets/electronics/photos/PIR MOTION SENSOR.jpeg",
    "description": "PIR Motion Sensor (HC-SR501) is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 11,
    "name": "IR Obstacle Avoidance Sensor",
    "category": "Sensors",
    "slug": "ir-obstacle-avoidance-sensor",
    "image": "assets/electronics/photos/IR Obstacle Avoidance sensor.jpeg",
    "description": "IR Obstacle Avoidance Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 12,
    "name": "MQ-2 Gas/Smoke Sensor",
    "category": "Sensors",
    "slug": "mq-2-gas-smoke-sensor",
    "image": "assets/electronics/photos/MQ-2 Gas smoke sensor.jpeg",
    "description": "MQ-2 Gas/Smoke Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 13,
    "name": "MQ-135 Air Quality Sensor",
    "category": "Sensors",
    "slug": "mq-135-air-quality-sensor",
    "image": "assets/electronics/photos/MQ-135 Air Quality sensor.jpeg",
    "description": "MQ-135 Air Quality Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 14,
    "name": "Soil Moisture Sensor",
    "category": "Sensors",
    "slug": "soil-moisture-sensor",
    "image": "assets/electronics/photos/Soil moisture sensor.jpeg",
    "description": "Soil Moisture Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 15,
    "name": "Raindrops Sensor",
    "category": "Sensors",
    "slug": "raindrops-sensor",
    "image": "assets/electronics/photos/Rain drop sensor.jpeg",
    "description": "Raindrops Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 16,
    "name": "Sound Sensor Module",
    "category": "Sensors",
    "slug": "sound-sensor-module",
    "image": "assets/electronics/photos/Sound sensor module.jpeg",
    "description": "Sound Sensor Module is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 17,
    "name": "KY-008 Laser Transmitter",
    "category": "Sensors",
    "slug": "ky-008-laser-transmitter",
    "image": "assets/electronics/photos/KY-008 Lasser Transmitter.jpeg",
    "description": "KY-008 Laser Transmitter is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Intermediate",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 18,
    "name": "Laser Receiver Module",
    "category": "Sensors",
    "slug": "laser-receiver-module",
    "image": "assets/electronics/photos/Laser recever module.jpeg",
    "description": "Laser Receiver Module is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Intermediate",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 19,
    "name": "MPU6050 Gyroscope & Accelerometer",
    "category": "Sensors",
    "slug": "mpu6050-gyroscope-accelerometer",
    "image": "assets/electronics/photos/MPU6050 Gyroscope and accelerometer.jpeg",
    "description": "MPU6050 Gyroscope & Accelerometer is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Intermediate",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 20,
    "name": "HC-SR505 Mini PIR Sensor",
    "category": "Sensors",
    "slug": "hc-sr505-mini-pir-sensor",
    "image": "assets/electronics/photos/HC-SR505 Mini PIR sensor.jpeg",
    "description": "HC-SR505 Mini PIR Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 21,
    "name": "TCS3200 Color Sensor",
    "category": "Sensors",
    "slug": "tcs3200-color-sensor",
    "image": "assets/electronics/photos/TCS3200 Color sensor.jpeg",
    "description": "TCS3200 Color Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 22,
    "name": "RC522 RFID Module",
    "category": "Sensors",
    "slug": "rc522-rfid-module",
    "image": "assets/electronics/photos/RC522 RFID MODULE.jpeg",
    "description": "RC522 RFID Module is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 23,
    "name": "Water Level Sensor",
    "category": "Sensors",
    "slug": "water-level-sensor",
    "image": "assets/electronics/photos/Water Level sensor.jpeg",
    "description": "Water Level Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 24,
    "name": "Flame Sensor",
    "category": "Sensors",
    "slug": "flame-sensor",
    "image": "assets/electronics/photos/Flame sensor.jpeg",
    "description": "Flame Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 25,
    "name": "BMP280 Barometric Pressure Sensor",
    "category": "Sensors",
    "slug": "bmp280-barometric-pressure-sensor",
    "image": "assets/electronics/photos/BMP280 Barometric Pressure Sensor.jpeg",
    "description": "BMP280 Barometric Pressure Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 26,
    "name": "Pulse/Heart Rate Sensor",
    "category": "Sensors",
    "slug": "pulse-heart-rate-sensor",
    "image": "assets/electronics/photos/Pulse Heart rate Sensor.jpeg",
    "description": "Pulse/Heart Rate Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 27,
    "name": "Flex Sensor",
    "category": "Sensors",
    "slug": "flex-sensor",
    "image": "assets/electronics/photos/Flex sensor.jpeg",
    "description": "Flex Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 28,
    "name": "SW-420 Vibration Sensor",
    "category": "Sensors",
    "slug": "sw-420-vibration-sensor",
    "image": "assets/electronics/photos/SW420 Vibration Sensor.jpeg",
    "description": "SW-420 Vibration Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 29,
    "name": "TTP223B Touch Sensor",
    "category": "Sensors",
    "slug": "ttp223b-touch-sensor",
    "image": "assets/electronics/photos/TTP223B Touch sensor.jpeg",
    "description": "TTP223B Touch Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 30,
    "name": "Hall Effect Sensor",
    "category": "Sensors",
    "slug": "hall-effect-sensor",
    "image": "assets/electronics/photos/Hall Effect Sensor.jpeg",
    "description": "Hall Effect Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 31,
    "name": "Tilt Sensor",
    "category": "Sensors",
    "slug": "tilt-sensor",
    "image": "assets/electronics/photos/Tilt Sensor.jpg",
    "description": "Tilt Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 32,
    "name": "Joystick Module",
    "category": "Sensors",
    "slug": "joystick-module",
    "image": "assets/electronics/photos/Joystick Module.jpg",
    "description": "Joystick Module is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 33,
    "name": "DS18B20 Waterproof Temperature Sensor",
    "category": "Sensors",
    "slug": "ds18b20-waterproof-temperature-sensor",
    "image": "assets/electronics/photos/DS18B20 Waterproof Temp Sensor.jpg",
    "description": "DS18B20 Waterproof Temperature Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 34,
    "name": "Turbidity Sensor",
    "category": "Sensors",
    "slug": "turbidity-sensor",
    "image": "assets/electronics/photos/Turbidity Sensor.jpg",
    "description": "Turbidity Sensor is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 35,
    "name": "LM393 Speed Sensor Module",
    "category": "Sensors",
    "slug": "lm393-speed-sensor-module",
    "image": "assets/electronics/photos/LM393 Speed Sensor Module.jpg",
    "description": "LM393 Speed Sensor Module is an educational electronics component used in sensors projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "sensors",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 36,
    "name": "16x2 LCD Display",
    "category": "Displays",
    "slug": "16x2-lcd-display",
    "image": "assets/electronics/photos/16x2 LCD Display.jpg",
    "description": "16x2 LCD Display is an educational electronics component used in displays projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "displays",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 37,
    "name": "I2C LCD Adapter Module",
    "category": "Displays",
    "slug": "i2c-lcd-adapter-module",
    "image": "assets/electronics/photos/I2C LCD Adapter Module.jpg",
    "description": "I2C LCD Adapter Module is an educational electronics component used in displays projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "displays",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 38,
    "name": "0.96 inch OLED Display",
    "category": "Displays",
    "slug": "0-96-inch-oled-display",
    "image": "assets/electronics/photos/0.96 inch OLED Display.jpg",
    "description": "0.96 inch OLED Display is an educational electronics component used in displays projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "displays",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 39,
    "name": "SG90 Servo Motor",
    "category": "Motors & Drivers",
    "slug": "sg90-servo-motor",
    "image": "assets/electronics/photos/SG90 Servo Motor.jpg",
    "description": "SG90 Servo Motor is an educational electronics component used in motors & drivers projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "motors & drivers",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 40,
    "name": "MG996R High Torque Servo Motor",
    "category": "Motors & Drivers",
    "slug": "mg996r-high-torque-servo-motor",
    "image": "assets/electronics/photos/MG996R High Torque Servo Motor.jpg",
    "description": "MG996R High Torque Servo Motor is an educational electronics component used in motors & drivers projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "motors & drivers",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 41,
    "name": "28BYJ-48 Stepper Motor",
    "category": "Motors & Drivers",
    "slug": "28byj-48-stepper-motor",
    "image": "assets/electronics/photos/28BYJ-48 Stepper Motor.jpg",
    "description": "28BYJ-48 Stepper Motor is an educational electronics component used in motors & drivers projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "motors & drivers",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 42,
    "name": "ULN2003 Stepper Motor Driver",
    "category": "Motors & Drivers",
    "slug": "uln2003-stepper-motor-driver",
    "image": "assets/electronics/photos/ULN2003 Stepper Motor Driver.jpg",
    "description": "ULN2003 Stepper Motor Driver is an educational electronics component used in motors & drivers projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "motors & drivers",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 43,
    "name": "DC Toy Motor (3V-6V)",
    "category": "Motors & Drivers",
    "slug": "dc-toy-motor-3v-6v",
    "image": "assets/electronics/photos/DC Toy Motor (3V-6V).jpg",
    "description": "DC Toy Motor (3V-6V) is an educational electronics component used in motors & drivers projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "motors & drivers",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 44,
    "name": "L298N Motor Driver Module",
    "category": "Actuators & Output",
    "slug": "l298n-motor-driver-module",
    "image": "assets/electronics/photos/L298N Motor Driver Module.jpg",
    "description": "L298N Motor Driver Module is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 45,
    "name": "L293D Motor Shield",
    "category": "Actuators & Output",
    "slug": "l293d-motor-shield",
    "image": "assets/electronics/photos/L293D Motor Shield.jpg",
    "description": "L293D Motor Shield is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 46,
    "name": "Active Buzzer",
    "category": "Actuators & Output",
    "slug": "active-buzzer",
    "image": "assets/electronics/photos/Active Buzzer.jpg",
    "description": "Active Buzzer is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 47,
    "name": "Passive Buzzer",
    "category": "Actuators & Output",
    "slug": "passive-buzzer",
    "image": "assets/electronics/photos/Passive Buzzer.jpg",
    "description": "Passive Buzzer is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 48,
    "name": "5V Single Channel Relay Module",
    "category": "Actuators & Output",
    "slug": "5v-single-channel-relay-module",
    "image": "assets/electronics/photos/5V Single Channel Relay Module.jpg",
    "description": "5V Single Channel Relay Module is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 49,
    "name": "4-Channel Relay Module",
    "category": "Actuators & Output",
    "slug": "4-channel-relay-module",
    "image": "assets/electronics/photos/4-Channel Relay Module.jpg",
    "description": "4-Channel Relay Module is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 50,
    "name": "MAX7219 8x8 LED Dot Matrix",
    "category": "Actuators & Output",
    "slug": "max7219-8x8-led-dot-matrix",
    "image": "assets/electronics/photos/MAX7219 8x8 LED Dot Matrix.jpg",
    "description": "MAX7219 8x8 LED Dot Matrix is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 51,
    "name": "7 Segment Display (1-Digit)",
    "category": "Actuators & Output",
    "slug": "7-segment-display-1-digit",
    "image": "assets/electronics/photos/7 Segment Display 1 Digit.jpg",
    "description": "7 Segment Display (1-Digit) is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 52,
    "name": "4-Digit 7 Segment Display",
    "category": "Actuators & Output",
    "slug": "4-digit-7-segment-display",
    "image": "assets/electronics/photos/4 digit 7 segment display.jpg",
    "description": "4-Digit 7 Segment Display is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 53,
    "name": "12V Solenoid Lock",
    "category": "Actuators & Output",
    "slug": "12v-solenoid-lock",
    "image": "assets/electronics/photos/12V Solenoid Lock.jpg",
    "description": "12V Solenoid Lock is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 54,
    "name": "Mini 3V-6V DC Water Pump",
    "category": "Actuators & Output",
    "slug": "mini-3v-6v-dc-water-pump",
    "image": "assets/electronics/photos/Mini 3V-6V DC Water Pump.jpg",
    "description": "Mini 3V-6V DC Water Pump is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 55,
    "name": "RGB LED Module",
    "category": "Actuators & Output",
    "slug": "rgb-led-module",
    "image": "assets/electronics/photos/RGB LED Module.jpg",
    "description": "RGB LED Module is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 56,
    "name": "WS2812B NeoPixel LED Strip",
    "category": "Actuators & Output",
    "slug": "ws2812b-neopixel-led-strip",
    "image": "assets/electronics/photos/WS2812B NeoPixel LED Strip.jpg",
    "description": "WS2812B NeoPixel LED Strip is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 57,
    "name": "Mini Vibration Motor",
    "category": "Actuators & Output",
    "slug": "mini-vibration-motor",
    "image": "assets/electronics/photos/Mini Vibration Motor.jpg",
    "description": "Mini Vibration Motor is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 58,
    "name": "Laser Diode Module",
    "category": "Actuators & Output",
    "slug": "laser-diode-module",
    "image": "assets/electronics/photos/Laser Diode Module.jpg",
    "description": "Laser Diode Module is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 59,
    "name": "4x4 Matrix Keypad",
    "category": "Actuators & Output",
    "slug": "4x4-matrix-keypad",
    "image": "assets/electronics/photos/4x4 Matrix Keypad.jpg",
    "description": "4x4 Matrix Keypad is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 60,
    "name": "Nextion HMI Touch Display",
    "category": "Actuators & Output",
    "slug": "nextion-hmi-touch-display",
    "image": "assets/electronics/photos/Nextion HMI Touch Display.jpg",
    "description": "Nextion HMI Touch Display is an educational electronics component used in actuators & output projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "actuators & output",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 61,
    "name": "HC-05 Bluetooth Module",
    "category": "Communication",
    "slug": "hc-05-bluetooth-module",
    "image": "assets/electronics/photos/HC-05 Bluetooth Module.jpg",
    "description": "HC-05 Bluetooth Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 62,
    "name": "HC-06 Bluetooth Module",
    "category": "Communication",
    "slug": "hc-06-bluetooth-module",
    "image": "assets/electronics/photos/HC-06 Bluetooth Module.jpg",
    "description": "HC-06 Bluetooth Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 63,
    "name": "NRF24L01 Transceiver Module",
    "category": "Communication",
    "slug": "nrf24l01-transceiver-module",
    "image": "assets/electronics/photos/NRF24L01 Transceiver Module.jpg",
    "description": "NRF24L01 Transceiver Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 64,
    "name": "SIM800L GSM/GPRS Module",
    "category": "Communication",
    "slug": "sim800l-gsm-gprs-module",
    "image": "assets/electronics/photos/SIM800L GSM.jpg",
    "description": "SIM800L GSM/GPRS Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Intermediate",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 65,
    "name": "NEO-6M GPS Module",
    "category": "Communication",
    "slug": "neo-6m-gps-module",
    "image": "assets/electronics/photos/NEO-6M GPS Module.jpg",
    "description": "NEO-6M GPS Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 66,
    "name": "IR Wireless Remote Receiver Kit",
    "category": "Communication",
    "slug": "ir-wireless-remote-receiver-kit",
    "image": "assets/electronics/photos/IR Wireless Remote Receiver Kit.jpg",
    "description": "IR Wireless Remote Receiver Kit is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 67,
    "name": "433MHz RF Transmitter-Receiver",
    "category": "Communication",
    "slug": "433mhz-rf-transmitter-receiver",
    "image": "assets/electronics/photos/433MHz RF Transmitter-Receiver.jpg",
    "description": "433MHz RF Transmitter-Receiver is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 68,
    "name": "ENC28J60 Ethernet Module",
    "category": "Communication",
    "slug": "enc28j60-ethernet-module",
    "image": "assets/electronics/photos/ENC28J60 Ethernet Module.jpg",
    "description": "ENC28J60 Ethernet Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 69,
    "name": "W5500 Ethernet Shield",
    "category": "Communication",
    "slug": "w5500-ethernet-shield",
    "image": "assets/electronics/photos/W5500 Ethernet Shield.jpg",
    "description": "W5500 Ethernet Shield is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 70,
    "name": "PN532 NFC Module",
    "category": "Communication",
    "slug": "pn532-nfc-module",
    "image": "assets/electronics/photos/PN532 NFC Module.jpg",
    "description": "PN532 NFC Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Intermediate",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 71,
    "name": "APC220 Wireless Module",
    "category": "Communication",
    "slug": "apc220-wireless-module",
    "image": "assets/electronics/photos/APC220 Wireless Module.jpg",
    "description": "APC220 Wireless Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 72,
    "name": "HC-12 Long Range Wireless Module",
    "category": "Communication",
    "slug": "hc-12-long-range-wireless-module",
    "image": "assets/electronics/photos/HC-12 Long Range Wireless Module.jpg",
    "description": "HC-12 Long Range Wireless Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 73,
    "name": "HM-10 Bluetooth 4.0 BLE Module",
    "category": "Communication",
    "slug": "hm-10-bluetooth-4-0-ble-module",
    "image": "assets/electronics/photos/HM-10 Bluetooth 4.0 BLE Module.jpg",
    "description": "HM-10 Bluetooth 4.0 BLE Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 74,
    "name": "ESP-01 Wi-Fi Module",
    "category": "Communication",
    "slug": "esp-01-wi-fi-module",
    "image": "assets/electronics/photos/ESP-01 Wi-Fi Module.jpg",
    "description": "ESP-01 Wi-Fi Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 75,
    "name": "A9G GSM/GPRS/GPS Module",
    "category": "Communication",
    "slug": "a9g-gsm-gprs-gps-module",
    "image": "assets/electronics/photos/A9G GSM.jpg",
    "description": "A9G GSM/GPRS/GPS Module is an educational electronics component used in communication projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Intermediate",
    "tags": [
      "communication",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 76,
    "name": "MB102 Breadboard Power Supply Module",
    "category": "Power & Utilities",
    "slug": "mb102-breadboard-power-supply-module",
    "image": "assets/electronics/photos/MB102 Breadboard Power Supply Module.jpg",
    "description": "MB102 Breadboard Power Supply Module is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 77,
    "name": "18650 Battery Holder",
    "category": "Power & Utilities",
    "slug": "18650-battery-holder",
    "image": "assets/electronics/photos/18650 Battery Holder.jpg",
    "description": "18650 Battery Holder is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 78,
    "name": "TP4056 Lithium Battery Charger",
    "category": "Power & Utilities",
    "slug": "tp4056-lithium-battery-charger",
    "image": "assets/electronics/photos/TP4056 Lithium Battery Charger.jpg",
    "description": "TP4056 Lithium Battery Charger is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 79,
    "name": "LM2596 Buck Converter",
    "category": "Power & Utilities",
    "slug": "lm2596-buck-converter",
    "image": "assets/electronics/photos/LM2596 Buck Converter.jpg",
    "description": "LM2596 Buck Converter is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Intermediate",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 80,
    "name": "XL6009 Boost Converter",
    "category": "Power & Utilities",
    "slug": "xl6009-boost-converter",
    "image": "assets/electronics/photos/XL6009 Boost Converter.jpg",
    "description": "XL6009 Boost Converter is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Intermediate",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 81,
    "name": "9V Battery Snap Connector",
    "category": "Power & Utilities",
    "slug": "9v-battery-snap-connector",
    "image": "assets/electronics/081-9v-battery-snap-connector.svg",
    "description": "9V Battery Snap Connector is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 82,
    "name": "DS3231 RTC Module",
    "category": "Power & Utilities",
    "slug": "ds3231-rtc-module",
    "image": "assets/electronics/photos/DS3231 RTC Module.jpg",
    "description": "DS3231 RTC Module is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 83,
    "name": "Micro SD Card Reader Module",
    "category": "Power & Utilities",
    "slug": "micro-sd-card-reader-module",
    "image": "assets/electronics/photos/Micro SD Card Reader Module.jpg",
    "description": "Micro SD Card Reader Module is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 84,
    "name": "5V 1A Wall Adapter",
    "category": "Power & Utilities",
    "slug": "5v-1a-wall-adapter",
    "image": "assets/electronics/photos/5V 1A Wall Adapter.jpg",
    "description": "5V 1A Wall Adapter is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 85,
    "name": "12V 2A Power Adapter",
    "category": "Power & Utilities",
    "slug": "12v-2a-power-adapter",
    "image": "assets/electronics/photos/12V 2A Power Adapter.jpg",
    "description": "12V 2A Power Adapter is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 86,
    "name": "DC Barrel Jack Adapter (Female)",
    "category": "Power & Utilities",
    "slug": "dc-barrel-jack-adapter-female",
    "image": "assets/electronics/photos/DC Barrel Jack Adapter (Female).jpg",
    "description": "DC Barrel Jack Adapter (Female) is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 87,
    "name": "DC Barrel Jack Adapter (Male)",
    "category": "Power & Utilities",
    "slug": "dc-barrel-jack-adapter-male",
    "image": "assets/electronics/photos/DC Barrel Jack Adapter (Male).jpg",
    "description": "DC Barrel Jack Adapter (Male) is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 88,
    "name": "Logic Level Converter (5V to 3.3V)",
    "category": "Power & Utilities",
    "slug": "logic-level-converter-5v-to-3-3v",
    "image": "assets/electronics/photos/Logic Level Converter 5V to 3.3V.jpg",
    "description": "Logic Level Converter (5V to 3.3V) is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Intermediate",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 89,
    "name": "18650 Li-ion Battery (3.7V)",
    "category": "Power & Utilities",
    "slug": "18650-li-ion-battery-3-7v",
    "image": "assets/electronics/photos/18650 Li-ion Battery.jpg",
    "description": "18650 Li-ion Battery (3.7V) is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 90,
    "name": "Mini Solar Panel (5V/6V)",
    "category": "Power & Utilities",
    "slug": "mini-solar-panel-5v-6v",
    "image": "assets/electronics/photos/Mini Solar Panel.jpg",
    "description": "Mini Solar Panel (5V/6V) is an educational electronics component used in power & utilities projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "power & utilities",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 91,
    "name": "220Ω Resistor",
    "category": "Basic Components",
    "slug": "220-resistor",
    "image": "assets/electronics/photos/220#U03a9 Resistor.jpg",
    "description": "220Ω Resistor is an educational electronics component used in basic components projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "basic components",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 92,
    "name": "1kΩ Resistor",
    "category": "Basic Components",
    "slug": "1k-resistor",
    "image": "assets/electronics/photos/1k Ohm Resistor.jpg",
    "description": "1kΩ Resistor is an educational electronics component used in basic components projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "basic components",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 93,
    "name": "10kΩ Resistor",
    "category": "Basic Components",
    "slug": "10k-resistor",
    "image": "assets/electronics/photos/10k Ohm Resistor.jpg",
    "description": "10kΩ Resistor is an educational electronics component used in basic components projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "basic components",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 94,
    "name": "10k Potentiometer",
    "category": "Basic Components",
    "slug": "10k-potentiometer",
    "image": "assets/electronics/photos/10k Potentiometer.jpg",
    "description": "10k Potentiometer is an educational electronics component used in basic components projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "basic components",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 95,
    "name": "Electrolytic Capacitor",
    "category": "Basic Components",
    "slug": "electrolytic-capacitor",
    "image": "assets/electronics/photos/Electrolytic Capacitor.jpg",
    "description": "Electrolytic Capacitor is an educational electronics component used in basic components projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "basic components",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 96,
    "name": "Ceramic Capacitor",
    "category": "Basic Components",
    "slug": "ceramic-capacitor",
    "image": "assets/electronics/photos/Ceramic Capacitor.jpg",
    "description": "Ceramic Capacitor is an educational electronics component used in basic components projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "basic components",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 97,
    "name": "5mm Red LED",
    "category": "Basic Components",
    "slug": "5mm-red-led",
    "image": "assets/electronics/photos/5mm Red LED.jpg",
    "description": "5mm Red LED is an educational electronics component used in basic components projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "basic components",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 98,
    "name": "Push Button Switch",
    "category": "Basic Components",
    "slug": "push-button-switch",
    "image": "assets/electronics/photos/Push Button Switch.jpg",
    "description": "Push Button Switch is an educational electronics component used in basic components projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "basic components",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 99,
    "name": "Slide Switch",
    "category": "Basic Components",
    "slug": "slide-switch",
    "image": "assets/electronics/photos/Slide Switch.jpg",
    "description": "Slide Switch is an educational electronics component used in basic components projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "basic components",
      "electronics",
      "nexora",
      "education"
    ]
  },
  {
    "id": 100,
    "name": "1N4007 Diode",
    "category": "Basic Components",
    "slug": "1n4007-diode",
    "image": "assets/electronics/photos/1N4007 Diode.jpg",
    "description": "1N4007 Diode is an educational electronics component used in basic components projects. Explore its purpose, typical interfaces, practical applications, and beginner-friendly project ideas.",
    "how": "Connect it according to the module pinout and operate it within the component's rated limits. Exact specifications can vary by manufacturer and module revision.",
    "applications": [
      "Student prototypes",
      "Robotics",
      "IoT experiments",
      "Automation",
      "Embedded learning"
    ],
    "difficulty": "Beginner",
    "tags": [
      "basic components",
      "electronics",
      "nexora",
      "education"
    ]
  }
];
