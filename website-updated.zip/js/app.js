import {
  fetchTeam, fetchProjects, fetchProjectById, watchAuth
} from "./data.js";
import { JOURNEY_STORY, PROJECT_CATEGORIES, TEAM_SEED, SITE_CONTENT_SEED, PROJECTS_SEED, UPDATES_SEED } from "./seed-data.js";
import { ELECTRONICS } from "./electronics-data.js";

// ============================================================
// Small utilities
// ============================================================
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
export const escapeHtml = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export const fmtDate = (ts) => {
  try {
    const d = ts?.toDate ? ts.toDate() : (ts ? new Date(ts) : null);
    if (!d || isNaN(d)) return "";
    return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  } catch { return ""; }
};

export function toast(message, type = "success") {
  const root = $("#toast-root");
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  root.appendChild(el);
  setTimeout(() => { el.style.opacity = "0"; el.style.transform = "translateX(40px)"; el.style.transition = ".3s"; setTimeout(() => el.remove(), 300); }, 3200);
}

export function confirmDialog(message, { title = "Are you sure?", danger = true } = {}) {
  return new Promise((resolve) => {
    const root = $("#confirm-root");
    root.innerHTML = `
      <div class="confirm-overlay">
        <div class="glass confirm-box">
          <h4>${escapeHtml(title)}</h4>
          <p>${escapeHtml(message)}</p>
          <div class="confirm-actions">
            <button class="btn btn-ghost" id="confirm-cancel">Cancel</button>
            <button class="btn ${danger ? "btn-danger" : "btn-solid"}" id="confirm-ok">Confirm</button>
          </div>
        </div>
      </div>`;
    $("#confirm-cancel").onclick = () => { root.innerHTML = ""; resolve(false); };
    $("#confirm-ok").onclick = () => { root.innerHTML = ""; resolve(true); };
  });
}

function revealOnScroll() {
  const items = $$(".reveal:not(.in)");
  if (!items.length) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } });
  }, { threshold: 0.12 });
  items.forEach(i => io.observe(i));
}

// ============================================================
// Particle background (lightweight canvas)
// ============================================================
function initParticles() {
  const canvas = $("#particles");
  const ctx = canvas.getContext("2d");
  let w, h, particles;
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function resize() {
    w = canvas.width = canvas.offsetWidth;
    h = canvas.height = canvas.offsetHeight || window.innerHeight;
  }
  function make() {
    const count = Math.min(70, Math.floor((w * h) / 22000));
    particles = Array.from({ length: count }, () => ({
      x: Math.random() * w, y: Math.random() * h,
      r: Math.random() * 1.6 + 0.4,
      vx: (Math.random() - 0.5) * 0.25, vy: (Math.random() - 0.5) * 0.25,
      a: Math.random() * 0.5 + 0.15,
    }));
  }
  function tick() {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "#A71930";
    particles.forEach(p => {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0) p.x = w; if (p.x > w) p.x = 0;
      if (p.y < 0) p.y = h; if (p.y > h) p.y = 0;
      ctx.globalAlpha = p.a;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
    });
    ctx.globalAlpha = 1;
    if (!reduceMotion) requestAnimationFrame(tick);
  }
  window.addEventListener("resize", () => { resize(); make(); });
  resize(); make();
  tick();
}

// ============================================================
// Nav behaviour
// ============================================================
function initNav() {
  const nav = $("#nx-nav");
  window.addEventListener("scroll", () => nav.classList.toggle("scrolled", window.scrollY > 12));
  const burger = $("#nx-burger");
  const links = $("#nx-links");
  burger.addEventListener("click", () => { burger.classList.toggle("open"); links.classList.toggle("open"); });
  links.addEventListener("click", (e) => { if (e.target.tagName === "A") { burger.classList.remove("open"); links.classList.remove("open"); } });
}
function setActiveNav(path) {
  $$(".nx-links a").forEach(a => a.classList.toggle("active", a.dataset.route === path));
}

// ============================================================
// PAGE: HOME
// ============================================================
function pageHome() {
  // Render the Home page immediately from local seed data. Firebase hydrates it in the background.
  const site = SITE_CONTENT_SEED;
  const projects = (PROJECTS_SEED || []).slice(0, 3);
  const team = TEAM_SEED || [];
  const updates = (UPDATES_SEED || []).slice(0, 3);

  // Only TEAM + PROJECTS are cloud-managed. All other site content
  // (hero, about, updates, journey, footer, etc.) stays in the code.
  queueMicrotask(async () => {
    try {
      const [remoteProjects, remoteTeam] = await Promise.all([fetchProjects(), fetchTeam()]);
      if (location.hash === "#/home" || location.hash === "#" || !location.hash) {
        const html = renderHome(site, (remoteProjects || projects).slice(0,3), remoteTeam || team, updates);
        $("#app").innerHTML = html;
        revealOnScroll();
      }
    } catch (e) { console.warn("Firebase background sync skipped:", e); }
  });

  return renderHome(site, projects, team, updates);
}

function renderHome(site, projects, team, updates) {
  return `
  <div class="page">
    <section class="hero">
      <div class="hero-eyebrow reveal in">Nexora Innovators</div>
      <h1 class="reveal in">${escapeHtml(site.heroTitle)}</h1>
      <div class="subtitle reveal in">${escapeHtml(site.heroSubtitle)}</div>
      <p class="desc reveal in">${escapeHtml(site.heroDescription)}</p>
      <div class="hero-btns reveal in">
        <a href="#/projects" class="btn btn-solid">Explore Our Projects</a>
        <a href="#/team" class="btn btn-ghost">Meet Our Team</a>
        <a href="#/journey" class="btn btn-ghost">Our Journey</a>
      </div>
    </section>

    <section class="nx-section container reveal"><div class="section-head"><div class="section-tag">About Nexora</div><h2>Who We Are</h2><p>${escapeHtml(site.aboutText)}</p></div></section>
    <section class="nx-section container reveal"><div class="section-head"><div class="section-tag">Featured</div><h2>Featured Projects</h2><p>A look at what we're building right now.</p></div><div class="grid-cards">${projects.length ? projects.map(projectCard).join("") : emptyState("No projects yet — check back soon.")}</div></section>
    <section class="nx-section container reveal"><div class="section-head"><div class="section-tag">The Team</div><h2>Meet Our Team</h2><p>Six innovators, one shared mission.</p></div><div class="grid-team">${team.map(teamCard).join("")}</div></section>
    <section class="nx-section container reveal"><div class="glass" style="padding:44px 30px;text-align:center;"><div class="section-tag">Our Story</div><h2 style="margin-bottom:16px;">Our Journey</h2><p style="max-width:640px;margin:0 auto 26px;opacity:.8;line-height:1.7;">${escapeHtml(JOURNEY_STORY[1].slice(0, 200))}…</p><a href="#/journey" class="btn btn-solid">Read Our Full Journey</a></div></section>
    <section class="nx-section container reveal"><div class="section-head"><div class="section-tag">News</div><h2>Latest Updates</h2></div>${updates.length ? `<div class="timeline">${updates.map(updateItem).join("")}</div>` : emptyState("No updates published yet.")}</section>
  </div>`;
}

function projectCard(p) {
  const img = p.coverImageUrl
    ? `<img class="card-img" src="${escapeHtml(p.coverImageUrl)}" alt="${escapeHtml(p.title)}" loading="lazy">`
    : `<div class="card-img" style="display:flex;align-items:center;justify-content:center;font-family:Orbitron;color:var(--accent-red);font-size:13px;letter-spacing:.1em;">NO IMAGE</div>`;
  return `
  <div class="glass card reveal in">
    ${img}
    <div class="card-body">
      <div class="flex-c gap-2" style="justify-content:space-between;">
        <span class="badge">${escapeHtml(p.category || "Other")}</span>
        <span class="badge badge-status">${escapeHtml(p.status || "In Progress")}</span>
      </div>
      <h3 class="card-title">${escapeHtml(p.title)}</h3>
      <p class="card-desc">${escapeHtml(p.shortDescription || "")}</p>
      <div class="card-meta"><span>${fmtDate(p.createdAt)}</span></div>
      <a href="#/projects/${p.id}" class="btn btn-ghost btn-sm mt-1" style="align-self:flex-start;">View Project</a>
    </div>
  </div>`;
}

function teamCard(m) {
  const initials = (m.name || "?").split(" ").map(w => w[0]).slice(0, 2).join("");
  const avatar = m.imageUrl ? `<img src="${escapeHtml(m.imageUrl)}" alt="${escapeHtml(m.name)}">` : initials;
  return `
  <div class="glass team-card reveal in">
    <div class="team-avatar">${avatar}</div>
    <h3>${escapeHtml(m.name)}</h3>
    <div class="role">${escapeHtml(m.role)}${m.role !== m.category ? " • " + escapeHtml(m.category) : ""}</div>
    ${m.bio ? `<div class="cat">${escapeHtml(m.bio)}</div>` : ""}
  </div>`;
}

function updateItem(u) {
  return `
  <div class="timeline-item reveal in">
    <div class="timeline-dot"></div>
    <div class="glass timeline-card">
      <div class="flex-c gap-2" style="justify-content:space-between;margin-bottom:8px;">
        <span class="badge">${escapeHtml(u.category || "Update")}</span>
        <span style="font-size:12px;opacity:.55;">${fmtDate(u.createdAt)}</span>
      </div>
      <h3 style="font-size:17px;margin:0 0 6px;">${escapeHtml(u.title)}</h3>
      <p style="font-size:14px;opacity:.8;line-height:1.6;margin:0 0 6px;">${escapeHtml(u.content)}</p>
      <div style="font-size:12px;opacity:.5;">by ${escapeHtml(u.author || "Nexora Innovators")}</div>
    </div>
  </div>`;
}

function emptyState(msg) {
  return `<div class="state-box glass" style="grid-column:1/-1;">${escapeHtml(msg)}</div>`;
}
function loadingState() {
  return `<div class="state-box"><div class="spinner"></div>Loading…</div>`;
}
function errorState(msg = "Something went wrong. Please try again.") {
  return `<div class="state-box glass">⚠ ${escapeHtml(msg)}</div>`;
}

// ============================================================
// PAGE: TEAM
// ============================================================
async function pageTeam() {
  const team = await fetchTeam();
  return `
  <div class="page nx-section container">
    <div class="section-head">
      <div class="section-tag">Nexora Innovators</div>
      <h2>Our Team</h2>
      <p>Six members. Six skill sets. One team.</p>
    </div>
    <div class="grid-team">${team.map(teamCard).join("")}</div>
  </div>`;
}

// ============================================================
// PAGE: PROJECTS
// ============================================================
let _allProjects = [];
async function pageProjects() {
  _allProjects = await fetchProjects();
  return `
  <div class="page nx-section container">
    <div class="section-head">
      <div class="section-tag">Our Work</div>
      <h2>Projects</h2>
      <p>Robotics, electronics, software and more — built by Nexora Innovators.</p>
    </div>
    <div class="filters-bar">
      <input type="search" id="proj-search" placeholder="Search projects…" />
      <div class="chip-row" id="proj-chips">
        <button class="chip active" data-cat="All">All</button>
        ${PROJECT_CATEGORIES.map(c => `<button class="chip" data-cat="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join("")}
      </div>
    </div>
    <div class="grid-cards" id="proj-grid">
      ${_allProjects.length ? _allProjects.map(projectCard).join("") : emptyState("No projects published yet.")}
    </div>
  </div>`;
}
function wireProjectsPage() {
  const grid = $("#proj-grid");
  const search = $("#proj-search");
  const chips = $$("#proj-chips .chip");
  let activeCat = "All";
  function render() {
    const term = (search.value || "").toLowerCase().trim();
    const filtered = _allProjects.filter(p => {
      const matchesCat = activeCat === "All" || p.category === activeCat;
      const matchesTerm = !term || (p.title + " " + (p.shortDescription || "")).toLowerCase().includes(term);
      return matchesCat && matchesTerm;
    });
    grid.innerHTML = filtered.length ? filtered.map(projectCard).join("") : emptyState("No projects match your search.");
  }
  search?.addEventListener("input", render);
  chips.forEach(c => c.addEventListener("click", () => {
    chips.forEach(x => x.classList.remove("active"));
    c.classList.add("active");
    activeCat = c.dataset.cat;
    render();
  }));
}

// ============================================================
// PAGE: PROJECT DETAILS
// ============================================================
async function pageProjectDetails(id) {
  const p = await fetchProjectById(id);
  if (!p) return `<div class="page nx-section container">${errorState("Project not found.")}</div>`;
  const gallery = (p.galleryUrls || []).filter(Boolean);
  return `
  <div class="page nx-section container">
    <a href="#/projects" class="btn btn-ghost btn-sm mt-1" style="margin-bottom:26px;">&larr; Back to Projects</a>
    <div class="glass reveal in" style="overflow:hidden;">
      ${p.coverImageUrl ? `<img src="${escapeHtml(p.coverImageUrl)}" style="width:100%;max-height:440px;object-fit:cover;">` : ""}
      <div style="padding:34px;">
        <div class="flex-c gap-2" style="margin-bottom:14px;">
          <span class="badge">${escapeHtml(p.category || "Other")}</span>
          <span class="badge badge-status">${escapeHtml(p.status || "In Progress")}</span>
        </div>
        <h1 style="font-size:clamp(26px,4vw,38px);margin:0 0 10px;">${escapeHtml(p.title)}</h1>
        <div style="font-size:13px;opacity:.55;margin-bottom:22px;">Published ${fmtDate(p.createdAt)} ${p.updatedAt ? "· Updated " + fmtDate(p.updatedAt) : ""}</div>
        <p style="line-height:1.85;font-size:15.5px;opacity:.9;">${escapeHtml(p.description || p.shortDescription || "")}</p>

        ${p.technologies?.length ? `<div class="mt-3"><h3 style="font-size:16px;">Technologies</h3><div class="chip-row mt-1">${p.technologies.map(t => `<span class="chip">${escapeHtml(t)}</span>`).join("")}</div></div>` : ""}
        ${p.teamMemberNames?.length ? `<div class="mt-3"><h3 style="font-size:16px;">Team</h3><div class="chip-row mt-1">${p.teamMemberNames.map(t => `<span class="chip">${escapeHtml(t)}</span>`).join("")}</div></div>` : ""}
        ${p.challenges ? `<div class="mt-3"><h3 style="font-size:16px;">Challenges</h3><p style="opacity:.85;line-height:1.7;">${escapeHtml(p.challenges)}</p></div>` : ""}
        ${p.solutions ? `<div class="mt-3"><h3 style="font-size:16px;">Solutions</h3><p style="opacity:.85;line-height:1.7;">${escapeHtml(p.solutions)}</p></div>` : ""}
        ${p.achievements ? `<div class="mt-3"><h3 style="font-size:16px;">Achievements</h3><p style="opacity:.85;line-height:1.7;">${escapeHtml(p.achievements)}</p></div>` : ""}
        ${p.videoUrl ? `<div class="mt-3"><h3 style="font-size:16px;">Video</h3><div class="glass mt-1" style="aspect-ratio:16/9;overflow:hidden;"><iframe src="${escapeHtml(toEmbed(p.videoUrl))}" style="width:100%;height:100%;border:0;" allowfullscreen></iframe></div></div>` : ""}
        ${gallery.length ? `<div class="mt-3"><h3 style="font-size:16px;">Gallery</h3><div class="grid-cards mt-1">${gallery.map(g => `<img src="${escapeHtml(g)}" style="border-radius:12px;width:100%;aspect-ratio:4/3;object-fit:cover;" loading="lazy">`).join("")}</div></div>` : ""}
      </div>
    </div>
  </div>`;
}
function toEmbed(url) {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtu")) {
      const id = u.hostname.includes("youtu.be") ? u.pathname.slice(1) : u.searchParams.get("v");
      return `https://www.youtube.com/embed/${id}`;
    }
    return url;
  } catch { return url; }
}

// ============================================================
// PAGE: UPDATES
// ============================================================
async function pageUpdates() {
  const updates = UPDATES_SEED || [];
  return `
  <div class="page nx-section container">
    <div class="section-head">
      <div class="section-tag">Newsroom</div>
      <h2>Updates</h2>
      <p>Announcements, progress and achievements from the team.</p>
    </div>
    ${updates.length ? `<div class="timeline">${updates.map(updateItem).join("")}</div>` : emptyState("No updates yet.")}
  </div>`;
}

// ============================================================
// PAGE: JOURNEY
// ============================================================
async function pageJourney() {
  return `
  <div class="page nx-section container">
    <div class="section-head">
      <div class="section-tag">Our Story</div>
      <h2>The Journey of Nexora Innovators</h2>
    </div>
    <div class="glass journey-story reveal in" style="padding:44px 36px;">
      ${JOURNEY_STORY.map(p => `<p>${escapeHtml(p)}</p>`).join("")}
      <div class="journey-signoff">— Dhanuja Uthsara, Nexora Innovators</div>
    </div>
  </div>`;
}

// ============================================================
// PAGE: CONTACT
// ============================================================
async function pageContact() {
  return `
  <div class="page nx-section container">
    <div class="section-head">
      <div class="section-tag">NEXORA COMMUNICATION SYSTEM</div>
      <h2>Talk to NEXORA</h2>
      <p>Send us a message and continue the conversation in real time. Your message goes directly to the NEXORA Admin Inbox.</p>
    </div>

    <div class="contact-chat-wrap glass" style="max-width:980px;margin:0 auto;padding:0;overflow:hidden;">
      <div class="contact-chat-head">
        <div>
          <div class="contact-status"><span></span> NEXORA Communication</div>
          <h3 style="margin:8px 0 0;">Start a conversation</h3>
        </div>
        <div class="contact-live">● LIVE</div>
      </div>

      <div id="contact-start" style="padding:30px;">
        <form id="contact-start-form">
          <div class="grid-2">
            <div class="field"><label>Your Name</label><input name="name" required maxlength="80" placeholder="Your name"></div>
            <div class="field"><label>Email</label><input name="email" type="email" required maxlength="120" placeholder="you@example.com"></div>
          </div>
          <div class="field"><label>Subject</label><input name="subject" maxlength="120" placeholder="Project collaboration, question, etc."></div>
          <div class="field"><label>Message</label><textarea name="message" required maxlength="2000" placeholder="Write your message..."></textarea></div>
          <button class="btn btn-solid" type="submit" id="contact-start-btn">Start Conversation →</button>
        </form>
      </div>

      <div id="contact-chat" style="display:none;">
        <div id="contact-meta" style="padding:16px 22px;border-bottom:1px solid var(--border);font-size:13px;opacity:.75;"></div>
        <div id="contact-messages" class="contact-messages"></div>
        <form id="contact-message-form" class="contact-composer">
          <textarea id="contact-message-input" rows="2" maxlength="2000" required placeholder="Type your message…"></textarea>
          <button class="btn btn-solid" type="submit">Send</button>
        </form>
      </div>
    </div>

    <div class="contact-socials" style="max-width:980px;margin:22px auto 0;">
      <a class="glass social-link" href="https://whatsapp.com/channel/0029VbD7ZgEInlqQB8BaiW22" target="_blank" rel="noopener">💬 WhatsApp Channel <span>→</span></a>
      <a class="glass social-link" href="https://www.youtube.com/@NEXORAINNOVATORS" target="_blank" rel="noopener">▶️ YouTube <span>→</span></a>
    </div>
  </div>`;
}

let contactUnsubscribe = null;
function wireContactPage() {
  const startForm = $("#contact-start-form");
  const startBox = $("#contact-start");
  const chatBox = $("#contact-chat");
  const messagesBox = $("#contact-messages");
  const composer = $("#contact-message-form");
  const input = $("#contact-message-input");
  const meta = $("#contact-meta");

  function messageBubble(m) {
    const mine = m.senderType === "visitor";
    return `<div class="contact-bubble-row ${mine ? "mine" : "theirs"}">
      <div class="contact-bubble ${mine ? "mine" : "theirs"}">${escapeHtml(m.text || "")}</div>
    </div>`;
  }

  function openChat(id, info) {
    startBox.style.display = "none";
    chatBox.style.display = "block";
    meta.innerHTML = `<b>${escapeHtml(info.name)}</b> · ${escapeHtml(info.subject || "General enquiry")}<span style="float:right;">Conversation #${escapeHtml(id.slice(0,7))}</span>`;
    contactUnsubscribe?.();
    import("./data.js").then(({ watchContactMessages }) => {
      contactUnsubscribe = watchContactMessages(id, msgs => {
        messagesBox.innerHTML = msgs.length ? msgs.map(messageBubble).join("") :
          `<div style="text-align:center;opacity:.5;padding:45px;">Conversation started. Send your first message.</div>`;
        messagesBox.scrollTop = messagesBox.scrollHeight;
      });
    });
    sessionStorage.setItem("nexora_contact_id", id);
    sessionStorage.setItem("nexora_contact_info", JSON.stringify(info));
  }

  try {
    const savedId = sessionStorage.getItem("nexora_contact_id");
    const savedInfo = JSON.parse(sessionStorage.getItem("nexora_contact_info") || "null");
    if (savedId && savedInfo) openChat(savedId, savedInfo);
  } catch {}

  startForm?.addEventListener("submit", async e => {
    e.preventDefault();
    const btn = $("#contact-start-btn");
    btn.disabled = true; btn.textContent = "Connecting…";
    try {
      const { createContactConversation, sendContactMessage } = await import("./data.js");
      const fd = new FormData(startForm);
      const info = { name: fd.get("name"), email: fd.get("email"), subject: fd.get("subject") || "General enquiry" };
      const id = await createContactConversation(info);
      await sendContactMessage(id, fd.get("message"));
      openChat(id, info);
      toast("Conversation connected to NEXORA.", "success");
    } catch (err) {
      console.error(err);
      toast("Could not start the conversation. Please try again.", "error");
    } finally {
      btn.disabled = false; btn.textContent = "Start Conversation →";
    }
  });

  composer?.addEventListener("submit", async e => {
    e.preventDefault();
    const id = sessionStorage.getItem("nexora_contact_id");
    const text = input.value.trim();
    if (!id || !text) return;
    const btn = composer.querySelector("button");
    btn.disabled = true;
    try {
      const { sendContactMessage } = await import("./data.js");
      await sendContactMessage(id, text);
      input.value = "";
    } catch (err) {
      toast("Message failed to send.", "error");
    } finally { btn.disabled = false; input.focus(); }
  });
}


// ============================================================
// NEXORA TECHNOLOGY PLATFORM
// ============================================================
const PLATFORM_CATEGORIES = [
  ["⚡","Electronics","100+ component guides, sensors, modules, displays, power and practical electronics learning.","/electronics"],
  ["🤖","Robotics","Robots, motor control, autonomous systems, sensors and real-world builds.","/technology/robotics"],
  ["🌐","IoT","ESP32, ESP8266, Firebase, MQTT, dashboards and connected devices.","/technology/iot"],
  ["💻","Software","Web, mobile, APIs, cloud, databases, GitHub and software engineering.","/technology/software"],
  ["🧠","AI & ML","Computer vision, machine learning, AI automation and intelligent systems.","/technology/ai"],
  ["🔧","Automation","Embedded control, smart systems and industrial-style automation concepts.","/technology/automation"],
  ["🔬","Research","Experiments, prototypes, R&D notes and technical investigations.","/research"],
  ["📚","NEXORA Academy","Structured tutorials, programming, electronics, robotics and resources.","/learning"],
  ["📖","Documentation","Project guides, wiring notes, setup instructions and troubleshooting.","/documentation"],
];

async function pageTechnology(){
  return `<div class="page nx-section container">
    <div class="section-head"><div class="section-tag">NEXORA TECHNOLOGY</div><h2>Technology & Innovation</h2><p>Explore the technical areas behind NEXORA's projects, learning resources and research.</p></div>
    <div class="platform-grid">${PLATFORM_CATEGORIES.map(([icon,title,desc,path])=>`
      <a class="glass platform-card reveal in" href="#${path}" style="overflow:hidden;padding:0">
        <img src="assets/${({"/electronics":"electronics","/technology/robotics":"robotics","/technology/iot":"iot","/technology/software":"software","/technology/ai":"ai","/technology/automation":"automation","/research":"research","/learning":"learning","/documentation":"documentation"})[path] || "research"}-cover.svg" alt="${escapeHtml(title)}" style="width:100%;aspect-ratio:2.2/1;object-fit:cover">
        <div style="padding:20px"><div class="platform-icon">${icon}</div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(desc)}</p><span class="btn btn-ghost btn-sm">Explore →</span></div>
      </a>`).join("")}</div>
    <section class="nx-section" style="padding-bottom:0"><div class="glass" style="padding:28px">
      <div class="platform-stat"><strong>100+</strong><span>electronics learning resources already structured inside NEXORA.</span></div>
    </div></section>
  </div>`;
}

let _electronicsFiltered = ELECTRONICS;
async function pageElectronics(){
  const cats = [...new Set(ELECTRONICS.map(x=>x.category))];
  return `<div class="page nx-section container">
    <div class="section-head"><div class="section-tag">NEXORA ELECTRONICS LIBRARY</div><h2>100+ Electronics Resources</h2><p>Learn what each component does, how it works, where it is used and how it can become part of a project.</p></div>
    <div class="electronics-toolbar">
      <input id="electronics-search" type="search" placeholder="Search Arduino, sensor, motor, Wi-Fi…" aria-label="Search electronics">
      <select id="electronics-category" aria-label="Filter category"><option value="All">All categories</option>${cats.map(c=>`<option>${escapeHtml(c)}</option>`).join("")}</select>
    </div>
    <div class="chip-row" id="electronics-count" style="margin-bottom:18px"></div>
    <div class="electronics-grid" id="electronics-grid">${electronicsCards(ELECTRONICS)}</div>
  </div>`;
}
function electronicsCards(rows){
  return rows.map(e=>`<a class="glass e-card reveal in" href="#/electronics/${e.id}" aria-label="Open ${escapeHtml(e.name)}">
    <img src="${escapeHtml(e.image)}" alt="${escapeHtml(e.name)}" loading="lazy">
    <div class="e-card-body"><span class="badge">${escapeHtml(e.category)}</span><h3>${escapeHtml(e.name)}</h3><p>${escapeHtml(e.description)}</p></div>
  </a>`).join("");
}
function wireElectronicsPage(){
  const search=$("#electronics-search"), select=$("#electronics-category"), grid=$("#electronics-grid"), count=$("#electronics-count");
  const render=()=>{const q=(search.value||"").toLowerCase().trim(), c=select.value;
    _electronicsFiltered=ELECTRONICS.filter(e=>(c==="All"||e.category===c)&&(!q||(e.name+" "+e.category+" "+e.description+" "+e.tags.join(" ")).toLowerCase().includes(q)));
    grid.innerHTML=_electronicsFiltered.length?electronicsCards(_electronicsFiltered):emptyState("No electronics resources match your search.");
    count.innerHTML=`<span class="badge">${_electronicsFiltered.length} of ${ELECTRONICS.length} resources</span>`;
  };
  search.addEventListener("input",render); select.addEventListener("change",render); render();
}
async function pageElectronicsDetails(id){
  const e=ELECTRONICS.find(x=>String(x.id)===String(id));
  if(!e) return `<div class="page nx-section container">${errorState("Electronics resource not found.")}</div>`;
  const related=ELECTRONICS.filter(x=>x.category===e.category&&x.id!==e.id).slice(0,4);
  return `<div class="page nx-section container">
    <a href="#/electronics" class="btn btn-ghost btn-sm" style="margin-bottom:20px">← Electronics Library</a>
    <article class="glass e-detail reveal in">
      <div class="e-detail-hero"><img src="${escapeHtml(e.image)}" alt="${escapeHtml(e.name)}">
      <div class="e-detail-content"><span class="badge">${escapeHtml(e.category)}</span><h1 style="font-size:clamp(25px,4vw,42px);margin:12px 0">${escapeHtml(e.name)}</h1>
      <p style="line-height:1.8;opacity:.82">${escapeHtml(e.description)}</p>
      <div class="spec-grid"><div class="spec-item"><b>Difficulty</b><span>${e.difficulty}</span></div><div class="spec-item"><b>Learning Focus</b><span>${escapeHtml(e.category)}</span></div><div class="spec-item"><b>Use Cases</b><span>Prototype • Education • Innovation</span></div><div class="spec-item"><b>Resource ID</b><span>NX-E-${String(e.id).padStart(3,"0")}</span></div></div>
      <div class="tag-list">${e.tags.map(t=>`<span>${escapeHtml(t)}</span>`).join("")}</div></div></div>
      <div style="padding:30px">
        <div class="grid-2"><section><h3>How it works</h3><p style="line-height:1.8;opacity:.78">${escapeHtml(e.how)}</p></section><section><h3>Typical applications</h3><ul style="line-height:2;opacity:.78">${e.applications.map(a=>`<li>${escapeHtml(a)}</li>`).join("")}</ul></section></div>
        <div class="glass" style="padding:20px;margin-top:20px"><b style="color:var(--white)">Safety & learning note</b><p style="opacity:.7;line-height:1.7;margin-bottom:0">Always verify the exact module revision and manufacturer's rated voltage/current before wiring. Use appropriate protection and supervision for batteries, mains adapters, lasers and moving parts.</p></div>
        ${related.length?`<section style="margin-top:28px"><h3>Related ${escapeHtml(e.category)}</h3><div class="electronics-grid">${electronicsCards(related)}</div></section>`:""}
      </div>
    </article>
  </div>`;
}

async function pageLearning(){
  const lessons=[
    ["⚡","Electronics Fundamentals","Voltage, current, resistance, components, sensors and safe prototyping.","Beginner"],
    ["🤖","Robotics Basics","Motors, drivers, sensors, control logic and robot architecture.","Beginner"],
    ["💻","Programming","C/C++, JavaScript, web fundamentals, APIs and software practices.","Beginner → Advanced"],
    ["🌐","IoT Systems","ESP32/ESP8266, Firebase, MQTT and real-time dashboards.","Intermediate"],
    ["🧠","AI & Computer Vision","Vision concepts, intelligent automation and AI-enabled robotics.","Intermediate"],
    ["🔧","Embedded & Automation","Microcontrollers, control systems and practical automation.","Intermediate"],
  ];
  return `<div class="page nx-section container"><div class="section-head"><div class="section-tag">NEXORA ACADEMY</div><h2>Learning Hub</h2><p>Learn technology through practical, project-oriented resources.</p></div>
  <div class="learning-grid">${lessons.map(x=>`<div class="glass platform-card reveal in"><div class="platform-icon">${x[0]}</div><h3>${x[1]}</h3><p>${x[2]}</p><span class="badge">${x[3]}</span></div>`).join("")}</div>
  <section class="nx-section" style="padding-bottom:0"><div class="section-head"><div class="section-tag">START HERE</div><h3>Electronics Library</h3><p>Start with the 100-component reference library and use each component as a building block for your own project.</p><a href="#/electronics" class="btn btn-solid">Open Electronics Library</a></div></section>
  </div>`;
}
async function pageTechnologyArea(type){
  const map={robotics:["🤖","Robotics","Build and understand robots using sensors, motors, microcontrollers, control logic and autonomous systems."],
    iot:["🌐","IoT","Explore connected devices, ESP32/ESP8266, cloud data, Firebase, MQTT and real-time monitoring."],
    software:["💻","Software","Explore frontend, backend, mobile, APIs, databases, cloud and software engineering."],
    ai:["🧠","AI & ML","Explore machine learning, computer vision, AI automation and intelligent robotics."],
    automation:["🔧","Automation","Explore embedded control, smart systems, sensors, actuators and automated workflows."]};
  const x=map[type]||map.robotics;
  return `<div class="page nx-section container"><div class="section-head"><div class="section-tag">TECHNOLOGY</div><h2>${x[0]} ${x[1]}</h2><p>${x[2]}</p></div>
  <div class="glass" style="padding:34px"><h3>What to explore</h3><div class="platform-grid">${["Fundamentals","Practical Projects","Components & Tools","Tutorials","Documentation","Innovation Ideas"].map((t,i)=>`<div class="glass platform-card"><h3>${t}</h3><p>Curated NEXORA resources for ${x[1]} learners, builders and student innovators.</p></div>`).join("")}</div></div></div>`;
}
async function pageResearch(){
 return `<div class="page nx-section container"><div class="section-head"><div class="section-tag">R&D</div><h2>Research & Development</h2><p>Experiments, prototypes, technical investigations and future innovation.</p></div><div class="platform-grid">
 ${["Research Projects","Experiments","Prototypes","Technical Papers","Research Notes","Future Concepts"].map(t=>`<div class="glass platform-card"><div class="platform-icon">🔬</div><h3>${t}</h3><p>NEXORA research content can be documented here with methods, results, images, contributors and supporting documents.</p></div>`).join("")}</div></div>`;
}
async function pageDocumentation(){
 return `<div class="page nx-section container"><div class="section-head"><div class="section-tag">KNOWLEDGE BASE</div><h2>Documentation</h2><p>Project guides, wiring references, setup notes, APIs and troubleshooting resources.</p></div><div class="platform-grid">${["Project Guides","Electronics Guides","Wiring & Pinouts","Setup Guides","API Documentation","Troubleshooting"].map(t=>`<div class="glass platform-card"><div class="platform-icon">📖</div><h3>${t}</h3><p>Structured technical documentation for NEXORA projects and learning resources.</p></div>`).join("")}</div></div>`;
}


async function pageExtra(title,tag,icon,items){
 return `<div class="page nx-section container"><div class="section-head"><div class="section-tag">${tag}</div><h2>${icon} ${title}</h2><p>Explore NEXORA's growing technology, education and innovation platform.</p></div><div class="platform-grid">${items.map(t=>`<div class="glass platform-card"><div class="platform-icon">${icon}</div><h3>${t}</h3><p>Content for this area can be published through the NEXORA platform and connected to projects, learning resources, documentation and team work.</p></div>`).join("")}</div></div>`;
}
async function pageWorkshops(){return pageExtra("Workshops","LEARN TO BUILD","🛠",["Electronics Workshops","Robotics Workshops","IoT Sessions","Programming Sessions","AI Sessions","Project Showcases"]);}
async function pageAchievements(){return pageExtra("Achievements","MILESTONES","🏆",["Competitions","Awards","Certifications","Project Milestones","Innovation Highlights","Team Recognition"]);}
async function pageGallery(){return pageExtra("Gallery","VISUAL ARCHIVE","🖼️",["Projects","Electronics","Robotics","Workshops","Events","Team"]);}
async function pageCommunity(){return pageExtra("Community","NEXORA COMMUNITY","👥",["Student Projects","Community Events","Contributors","Learning Groups","Innovation Ideas","Community Highlights"]);}
// ============================================================
// PAGE: ADMIN LOGIN
// ============================================================
// The admin panel only asks for a password. Firebase Auth still
// requires an email/password pair under the hood, so we pair
// every login attempt with this fixed, non-secret email address.
// It is NOT the password and does not need to be kept secret —
// you just need to create the Firebase Auth user with this exact
// email (see README, section 2) and whatever password you choose.
const ADMIN_EMAIL = "admin@nexorainnovators.app";

async function pageAdminLogin() {
  return `
  <div class="page nx-section container" style="max-width:420px;">
    <div class="glass reveal in" style="padding:36px;">
      <h2 style="text-align:center;margin-top:0;">Admin Login</h2>
      <p style="text-align:center;opacity:.65;font-size:13px;margin-bottom:26px;">Enter the Nexora Innovators admin password.</p>
      <form id="admin-login-form">
        <div class="field"><label>Password</label><input type="password" id="admin-password" required autocomplete="current-password" autofocus /></div>
        <div id="login-error" class="field-error" style="display:none;"></div>
        <button type="submit" class="btn btn-solid" style="width:100%;" id="login-btn">Login</button>
      </form>
    </div>
  </div>`;
}
function wireAdminLoginPage() {
  const form = $("#admin-login-form");
  form?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#login-btn");
    const errBox = $("#login-error");
    errBox.style.display = "none";
    btn.disabled = true; btn.textContent = "Signing in…";
    try {
      const { loginAdmin } = await import("./data.js");
      await loginAdmin(ADMIN_EMAIL, $("#admin-password").value);
      toast("Welcome back!", "success");
      location.hash = "#/admin/dashboard";
    } catch (err) {
      errBox.textContent = "Incorrect password.";
      errBox.style.display = "block";
    } finally {
      btn.disabled = false; btn.textContent = "Login";
    }
  });
}

// ============================================================
// ROUTER
// ============================================================
const routes = {
  "/home": { render: pageHome, wire: null },
  "/team": { render: pageTeam, wire: null },
  "/technology": { render: pageTechnology, wire: null },
  "/electronics": { render: pageElectronics, wire: wireElectronicsPage },
  "/learning": { render: pageLearning, wire: null },
  "/research": { render: pageResearch, wire: null },
  "/documentation": { render: pageDocumentation, wire: null },
  "/workshops": { render: pageWorkshops, wire: null },
  "/achievements": { render: pageAchievements, wire: null },
  "/gallery": { render: pageGallery, wire: null },
  "/community": { render: pageCommunity, wire: null },
  "/technology/robotics": { render: () => pageTechnologyArea("robotics"), wire: null },
  "/technology/iot": { render: () => pageTechnologyArea("iot"), wire: null },
  "/technology/software": { render: () => pageTechnologyArea("software"), wire: null },
  "/technology/ai": { render: () => pageTechnologyArea("ai"), wire: null },
  "/technology/automation": { render: () => pageTechnologyArea("automation"), wire: null },
  "/team": { render: pageTeam, wire: null },
  "/projects": { render: pageProjects, wire: wireProjectsPage },
  "/updates": { render: pageUpdates, wire: null },
  "/journey": { render: pageJourney, wire: null },
  "/contact": { render: pageContact, wire: wireContactPage },
  "/admin/login": { render: pageAdminLogin, wire: wireAdminLoginPage },
};

let currentUser = null;
watchAuth((u) => { currentUser = u; });

async function router() {
  const app = $("#app");
  const hash = location.hash.replace(/^#/, "") || "/home";
  const [path, param] = (() => {
    const parts = hash.split("/").filter(Boolean);
    if (parts[0] === "projects" && parts[1]) return ["/projects/:id", parts[1]];
    if (parts[0] === "electronics" && parts[1]) return ["/electronics/:id", parts[1]];
    return ["/" + parts.join("/"), null];
  })();

  window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  setActiveNav(path.startsWith("/projects") ? "/projects" : path.startsWith("/admin") ? "/admin/login" : path);

  app.innerHTML = loadingState();

  try {
    if (path === "/projects/:id") {
      app.innerHTML = await pageProjectDetails(param);
      revealOnScroll();
      return;
    }
    if (hash.startsWith("/electronics/") && param) {
      app.innerHTML = await pageElectronicsDetails(param);
      revealOnScroll();
      return;
    }
    if (path === "/admin/dashboard") {
      const mod = await import("./admin.js");
      await mod.renderAdminDashboard(app, currentUser, () => { location.hash = "#/admin/login"; });
      return;
    }
    const route = routes[path] || routes["/home"];
    app.innerHTML = await route.render();
    revealOnScroll();
    route.wire && route.wire();
  } catch (err) {
    console.error(err);
    app.innerHTML = `<div class="page nx-section container">${errorState()}</div>`;
  }
}

window.addEventListener("hashchange", router);
window.addEventListener("DOMContentLoaded", async () => {
  initParticles();
  initNav();

  // Home renders immediately from local data. Firebase sync runs in the background.
  await router();
  $("#footer-year").textContent = new Date().getFullYear();
});
