# NEXORA INNOVATORS — Fast Static Team + Project Library

A responsive dark-glass NEXORA INNOVATORS website built with plain HTML/CSS/JavaScript.

## Data architecture

- **Team members: 100% local code/assets.** The six supplied member photos are bundled under `assets/team/` and are never stored in Firebase.
- **Electronics: 100 local code-managed resources.** Each component has its own image asset under `assets/electronics/`.
- **Project library: 351 local entries** (Smart Flow + 50 reference ideas in each of Robotics, Electronics, Software, Artificial Intelligence, IoT, Automation and Other).
- **Firebase:** used only for admin authentication, cloud-created project records, and project cover/gallery image uploads.
- **Admin link:** remains in the footer only.

The reference project library is an original NEXORA-curated set of project ideas inspired by common maker/Arduino/IoT patterns. Arduino Project Hub is a useful external reference for real-world project examples.

## Admin

Footer → **Admin**

Firebase Authentication uses the fixed admin email configured in the app:

`admin@nexorainnovators.app`

Set the password in Firebase Console. Do not put the password into HTML/JavaScript.

The Admin panel manages **Projects only**. Project forms support:

- Cover image upload
- Multiple gallery image uploads
- Category/status
- Technologies
- Team names
- Video URL
- Featured/published flags

Local reference projects are read-only. Saving a local reference project from Admin creates a Firebase project copy, which can then have uploaded images.

## Electronics

The website includes 100 individual component resources with local image assets, search, category filtering and detail pages.

## Run

No npm/build step is required.

```bash
python3 -m http.server 8080
```

Then open the local URL.

## Firebase rules

Deploy `firestore.rules` and `storage.rules` to the Firebase project. Firestore is restricted to the `projects` collection; team data is not stored in Firestore.
